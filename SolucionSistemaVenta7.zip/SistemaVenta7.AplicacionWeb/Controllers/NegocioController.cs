﻿using Microsoft.AspNetCore.Mvc;

namespace SistemaVenta7.AplicacionWeb.Controllers
{
    public class NegocioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
