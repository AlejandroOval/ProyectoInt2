﻿using Microsoft.AspNetCore.Mvc;

namespace SistemaVenta7.AplicacionWeb.Controllers
{
    public class ReporteVentaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
