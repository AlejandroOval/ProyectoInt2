
select * from Configuracion