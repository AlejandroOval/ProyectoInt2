﻿using Microsoft.AspNetCore.Mvc;

namespace SistemaVenta7.AplicacionWeb.Controllers
{
    public class CategoriaController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
