﻿using Microsoft.AspNetCore.Mvc;

namespace SistemaVenta7.AplicacionWeb.Controllers
{
    public class UsuarioController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
